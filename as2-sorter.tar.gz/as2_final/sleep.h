#ifndef SLEEP_H_
#define SLEEP_H_

// public functions
void slip(long sec, long nano);

#endif // SLEEP_H_


