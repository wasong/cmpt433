#include "run.h"
#include <stdio.h>

int main() {
	printf("Drive display (assumes GPIO #61 and #44 are output and 1)\n");
	run();

	return 0;
}
