# To implement in custom `main.c`, 

- include `run.h`
- call `run();` in main

# To build from the source,

- `make clean`
- `make i2c`
(`make i2c` will try to copy the executable to the BB remote folder)

