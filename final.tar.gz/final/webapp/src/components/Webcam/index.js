export default from './Webcam'
