import React from 'react'
import Radium from 'radium'

const Door = props => (
  <div>Door Lock</div>
)

export default Radium(Door)
