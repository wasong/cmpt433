export default from './Featured'
