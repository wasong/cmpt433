export default from './PaperBadge'
