module.exports = {
  title: 'SomeBoilerplate',
  url: '',
  trackingID: 'UA-XXXXX-Y',
  googleTagManager: {
    id: '',
  },
}
