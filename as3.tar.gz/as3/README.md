Run `make` then `npm start` to install node packages and start the server. Make sure to start `beatbox` on the BBB!
