
#ifndef _LEDS_H_
#define _LEDS_H_

 void initializeLeds(void);
 void bounceLeds(void);
 void barLeds(void);
 void busyWait(unsigned int count);

#endif
