#ifndef _LEDS_H_
#define _LEDS_H_

void initLEDS(void);

void bounceLEDPattern(void);
void barLEDPattern(void);
void busyWait(unsigned int count);

#endif
